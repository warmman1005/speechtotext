module.exports = {
  apiKeyGoogle: 'YOUR_GOOGLE_API_KEY',
  openAIKey: 'YOUR_OPENAI_API_KEY'
};
